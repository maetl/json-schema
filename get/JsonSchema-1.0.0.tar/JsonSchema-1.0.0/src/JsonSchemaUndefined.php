<?php
class JsonSchemaUndefined {}